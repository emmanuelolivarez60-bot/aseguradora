# Diagrama UML - Sistema VidaFutura

Este diagrama representa la estructura principal del proyecto refactorizado de la aseguradora **VidaFutura**.

```mermaid
classDiagram
    class Persona {
        <<abstract>>
        +str nombre
        +str apellidos
        +str fecha_nacimiento
        +capturar_persona()
        +obtener_valores()
    }

    class Transaccion {
        <<abstract>>
        +procesar() bool
    }

    class Cliente {
        +str genero
        +str curp
        +str telefono
        +str correo
        +str ocupacion
        +float ingreso_mensual
        +capturar()
        +obtener_valores()
        +obtener_columnas()
    }

    class Beneficiario {
        +str parentesco
        +float porcentaje_asignado
        +int poliza_id
        +capturar()
        +obtener_valores()
        +obtener_columnas()
    }

    class Poliza {
        +int numero_poliza
        +date fecha_inicio
        +date fecha_fin
        +float prima_mensual
        +float suma_asegurada
        +int tipo_poliza_id
        +int estatus_id
        +int cliente_id
        +capturar()
        +obtener_valores()
        +obtener_columnas()
    }

    class Pago {
        +date fecha_pago
        +float monto_pagado
        +int metodo_pago_id
        +str referencia
        +int poliza_id
        +capturar()
        +procesar() bool
        +obtener_valores()
        +obtener_columnas()
    }

    class Siniestro {
        +date fecha_reporte
        +date fecha_ocurrencia
        +int tipo_siniestro_id
        +float monto_reclamado
        +float monto_aprobado
        +str estatus_siniestro
        +int poliza_id
        +capturar()
        +procesar() bool
        +obtener_valores()
        +obtener_columnas()
    }

    class ConexionBD {
        +host
        +user
        +password
        +database
        +port
        +conectar()
        +obtener_conexion()
    }

    class RepositorioBD {
        +str tabla
        +list columnas
        +registrar()
        +consultar()
        +actualizar()
        +eliminar()
        +existe_valor()
        +existe_id()
        +sumar_porcentaje_beneficiarios()
        +consultar_pagos_por_poliza()
        +consultar_catalogo()
    }

    class GestorEntidadBD {
        +str nombre
        +clase
        +RepositorioBD repositorio
        +mostrar_menu()
        +registrar()
        +actualizar()
        +eliminar()
        +validar_relaciones()
        +ver_porcentaje_total()
        +consultar_pagos_por_poliza()
    }

    Persona <|-- Cliente
    Persona <|-- Beneficiario

    Transaccion <|-- Pago
    Transaccion <|-- Siniestro

    Cliente "1" --> "0..*" Poliza : tiene
    Poliza "1" --> "0..*" Beneficiario : asigna
    Poliza "1" --> "0..*" Pago : recibe
    Poliza "1" --> "0..*" Siniestro : reporta

    GestorEntidadBD ..> RepositorioBD : usa
    RepositorioBD ..> ConexionBD : conecta

    GestorEntidadBD ..> Cliente : administra
    GestorEntidadBD ..> Poliza : administra
    GestorEntidadBD ..> Beneficiario : administra
    GestorEntidadBD ..> Pago : administra
    GestorEntidadBD ..> Siniestro : administra
```

## Explicación breve

El sistema usa clases abstractas para representar comportamientos generales:

- `Persona` es una clase abstracta heredada por `Cliente` y `Beneficiario`.
- `Transaccion` es una clase abstracta heredada por `Pago` y `Siniestro`.

También se aplica refactorización separando responsabilidades:

- `ConexionBD` administra la conexión a MySQL.
- `RepositorioBD` centraliza las operaciones CRUD.
- `GestorEntidadBD` administra los menús y validaciones generales.
